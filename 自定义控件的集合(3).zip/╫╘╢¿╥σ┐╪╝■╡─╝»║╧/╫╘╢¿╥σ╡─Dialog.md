        
自定义的DialogRelativelayout的用法，这里我是自定义了一个ViewGroup，在构建Dialog的时候传入这个View就行，其中2.3.4步骤可以重复和混乱顺序，可根据需要自行组合。

		//1.创建这个DialogRelativelayout
		DialogRelativelayout dialogRelativelayout = new DialogRelativelayout(MainActivity.this);
		//2.传入的是红色字体的标题
        dialogRelativelayout.setStrTitle("测试标题");
		//3.传入的是黑色字体的二级标题
        dialogRelativelayout.setStrSecondTitle("预警异常");
		//4.传入的是一个ArrayList<String>
        dialogRelativelayout.setStrContent(titleList);
		/5.构建Dialog，setView的时候把这个View set进去。
        new AlertDialog.Builder(this).setView(dialogRelativelayout).setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        }).show();